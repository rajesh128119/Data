package com.cg.onlineshopping.bean;

import java.time.LocalDate;

public class Purchase {

	private int pId;
	private int custId;
	private int prodId;
	private LocalDate pDate;
	
	public Purchase()
	{
		
	}

	@Override
	public String toString() {
		return "Purchase [pId=" + pId + ", custId=" + custId + ", prodId="
				+ prodId + ", pDate=" + pDate + "]";
	}

	public int getpId() {
		return pId;
	}

	public void setpId(int pId) {
		this.pId = pId;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public int getProdId() {
		return prodId;
	}

	public void setProdId(int prodId) {
		this.prodId = prodId;
	}

	public LocalDate getpDate() {
		return pDate;
	}

	public void setpDate(LocalDate pDate) {
		this.pDate = pDate;
	}
}
