package com.cg.onlineshopping.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.onlineshopping.bean.Customer;
import com.cg.onlineshopping.bean.Product;
import com.cg.onlineshopping.exception.ShoppingException;
import com.cg.onlineshopping.service.ShoppingService;
import com.cg.onlineshopping.service.ShoppingServiceImpl;

/**
 * Servlet implementation class ShoppingController
 */
@WebServlet("/ShoppingController")
public class ShoppingController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	ShoppingService service;
	
	public ShoppingController()
	{
		service = new ShoppingServiceImpl();
	}
    /**
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = 
				request.getSession(true);
		String qStr = request.getParameter("action");
		if("home".equals(qStr))
		{
			RequestDispatcher dispatch = 
					request.getRequestDispatcher("login.jsp");
			dispatch.forward(request, response);
		}
		if("product".equals(qStr))
		{
			String prodId = request.getParameter("id");
			Customer cust = (Customer)session.getAttribute("customer");
			int custId = cust.getCustId();
			try {
				HashMap<LocalDate,Product>map
				= service.purchaseProduct(Integer.parseInt(prodId), custId);
				if(map.size()!=0)
				{
					session.setAttribute("map", map);
					RequestDispatcher dispatch = 
							request.getRequestDispatcher("success.jsp");
					dispatch.forward(request, response);
				}
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				response.sendRedirect("error.jsp");
			} catch (ShoppingException e) {
				// TODO Auto-generated catch block
				response.sendRedirect("error.jsp");
			}
		}
	}

	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = 
				request.getSession(false);
		String qStr = request.getParameter("action");
		if("login".equals(qStr))
		{
			String custName = request.getParameter("custName");
			int custId = Integer.parseInt(request.getParameter("custId"));
			Customer cust = new Customer();
			cust.setCustId(custId);
			cust.setCustName(custName);
			try {
				ArrayList<Product>list = 
						service.getProducts(cust);
				if(list.size()!=0){
				session.setAttribute("prodList", list);
				session.setAttribute("customer",cust);
				RequestDispatcher dispatch = 
						request.getRequestDispatcher("product.jsp");
				dispatch.forward(request, response);
				}
			} catch (ShoppingException e) {
				// TODO Auto-generated catch block
				response.sendRedirect("error.jsp");
			}
		}
	}

}
