package com.cg.onlineshopping.filter;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.cg.onlieshopping.logger.MyLogger;
import com.cg.onlineshopping.bean.Product;

@WebFilter("/OnlineShoppingFilter")
public class OnlineShoppingFilter implements Filter {

    /**
     * Default constructor. 
     */
    public OnlineShoppingFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		chain.doFilter(request, response);
		HttpServletRequest request1=(HttpServletRequest)request;
		String qString=request1.getParameter("action");
		if("dest".equals(qString))
		{
			HttpSession session=request1.getSession(false);
			HashMap<LocalDate,Product> map=(HashMap<LocalDate,Product>) session.getAttribute("map");
			String id=(String) session.getAttribute("id");
	//		org.Apache
			org.apache.log4j.Logger logger=MyLogger.getLoggerInstance();
			logger.info("list printed by DestinationController");
			logger.info(map);
	}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
		String id=fConfig.getInitParameter("id");
		 ServletContext context=fConfig.getServletContext();
		 context.setAttribute("id",id);
	}

}
