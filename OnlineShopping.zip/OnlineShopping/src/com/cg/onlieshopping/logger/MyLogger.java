package com.cg.onlieshopping.logger;

import java.io.IOException;

import org.apache.log4j.FileAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;


public class MyLogger {
	static Logger logger=Logger.getLogger(MyLogger.class);
	static 
	{
		SimpleLayout layout=new SimpleLayout();
		try{
		FileAppender appender= new FileAppender(layout,"P://JEE/log.txt");
		logger.addAppender(appender);
		}
		catch(IOException e)
		{
			e.getMessage();
		}
		
	}
	static public Logger getLoggerInstance()
	{
		return logger;
	}
}
