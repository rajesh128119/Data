package com.cg.onlinegames.exception;

public class OnlineGamesException extends Exception {
	String message;
	
	public OnlineGamesException(String message)
	{
		this.message = message;
	}
	
	@Override
	public String getMessage()
	{
		return message;
	}
	
}
