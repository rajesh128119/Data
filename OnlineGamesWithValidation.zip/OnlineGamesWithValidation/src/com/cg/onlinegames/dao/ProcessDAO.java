package com.cg.onlinegames.dao;

import java.util.ArrayList;

import com.cg.onlinegames.bean.GameBean;
import com.cg.onlinegames.bean.UserBean;
import com.cg.onlinegames.exception.OnlineGamesException;

public interface ProcessDAO {
	public UserBean insertUser(UserBean bean) throws OnlineGamesException;
	public ArrayList<GameBean> getGameList() throws OnlineGamesException;
}
