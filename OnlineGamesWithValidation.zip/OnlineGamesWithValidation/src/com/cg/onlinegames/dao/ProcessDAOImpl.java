package com.cg.onlinegames.dao;
import java.util.ArrayList;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;



import com.cg.onlinegames.bean.GameBean;
import com.cg.onlinegames.bean.UserBean;
import com.cg.onlinegames.exception.OnlineGamesException;

@Repository
public class ProcessDAOImpl implements ProcessDAO {

	/*Connection con;
	
	public ProcessDAOImpl()
	{
		con = DBUtil.getConnection();
	}*/
	
	@PersistenceContext
	private EntityManager entityManager;
	
	
	
	@Override
	public UserBean insertUser(UserBean bean) throws OnlineGamesException {
		entityManager.persist(bean);
		entityManager.flush();
		return bean;
		
		/*// TODO Auto-generated method stub
		
		int flag = 0;
		//insert user data in to users table
		String sql = "INSERT INTO users VALUES(seq_users.nextval,?,?,?)";
		
		//deduct service charge from user amount
		int service_charge = 100;
		int amount = bean.getPlay_amount() - service_charge;
		try {
			
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, bean.getName());
			pstmt.setString(2, bean.getAddress());
			pstmt.setInt(3, amount);
			
			int row = pstmt.executeUpdate();
			
			if(row>0)
			{
				flag = amount;
			}
			else
			{
				throw new OnlineGamesException("Insert Failed");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new OnlineGamesException(e.getMessage());
		}
		
		
		return flag;*/
	}



	@Override
	public ArrayList<GameBean> getGameList() throws OnlineGamesException {
		// TODO Auto-generated method stub
		String str = "SELECT gamebean FROM GameBean gamebean";
		TypedQuery<GameBean> query = entityManager.createQuery(str, GameBean.class);
		ArrayList<GameBean> gameList = (ArrayList<GameBean>) query.getResultList();
		
		return gameList;
	}

	/*@Override
	public ArrayList<GameBean> GameList() throws OnlineGamesException {
		// TODO Auto-generated method stub
		
		 ArrayList<GameBean> list = new  ArrayList<GameBean>();
		
		 //Fetching Game Details from database
		 
		String sql = "SELECT * FROM onlinegames";
		
		try {
			
			Statement st = con.createStatement();
			
			ResultSet rs = st.executeQuery(sql);
			while(rs.next())
			{
				GameBean bean = new GameBean();
				bean.setName(rs.getString(1));
				bean.setAmount(rs.getInt(2));
				
				list.add(bean);
			}
			
			if(list.size()==0)
			{
				throw new OnlineGamesException("Game Data Not Found");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new OnlineGamesException(e.getMessage());
		}
		
		
		return list;
	}*/

}
