package com.cg.onlinegames.service;

import java.util.ArrayList;

import com.cg.onlinegames.bean.GameBean;
import com.cg.onlinegames.bean.UserBean;
import com.cg.onlinegames.exception.OnlineGamesException;

public interface ProcessService {
	public UserBean insertUser(UserBean bean) throws OnlineGamesException;
	public ArrayList<GameBean> getGameList() throws OnlineGamesException;
}
