package com.cg.onlinegames.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cg.onlinegames.bean.GameBean;
import com.cg.onlinegames.bean.UserBean;
import com.cg.onlinegames.dao.ProcessDAO;
import com.cg.onlinegames.dao.ProcessDAOImpl;
import com.cg.onlinegames.exception.OnlineGamesException;

@Service
@Transactional
public class ProcessServiceImpl implements ProcessService {
	
	@Autowired
	ProcessDAO dao;
	
	/*public ProcessServiceImpl()
	{
		dao = new ProcessDAOImpl();
	}*/
	
	@Override
	public UserBean insertUser(UserBean bean) throws OnlineGamesException {
		// TODO Auto-generated method stub
		return dao.insertUser(bean);
	}

	@Override
	public ArrayList<GameBean> getGameList() throws OnlineGamesException {
		// TODO Auto-generated method stub
		return dao.getGameList();
	}

	
	

}
