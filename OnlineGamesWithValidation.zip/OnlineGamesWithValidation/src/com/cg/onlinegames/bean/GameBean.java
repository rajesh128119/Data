package com.cg.onlinegames.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Component
@Entity
public class GameBean {
	@Id
	private String name;
	private int amount;
	
	
	public GameBean() {
		super();
	}
	@Override
	public String toString() {
		return "GameBean [name=" + name + ", amount=" + amount + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
}
