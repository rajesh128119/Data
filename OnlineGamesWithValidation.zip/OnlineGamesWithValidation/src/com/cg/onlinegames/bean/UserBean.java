package com.cg.onlinegames.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.stereotype.Component;

@Component
@Entity
public class UserBean {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int user_id;
	@NotEmpty(message="Name is mandatory")
	@Size(min=4,max=20,message="Minimum 4 and Maximum 20 characters required")
	private String name;
	private String address;
	/*@Pattern(regexp="[0-9]+",message="Amount must be number")*/
	@Range(min=500,max=2000,message="Amount must between 500 and 2000")
	private int play_amount;
	
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getPlay_amount() {
		return play_amount;
	}
	public void setPlay_amount(int play_amount) {
		this.play_amount = play_amount;
	}
	
	public UserBean() {
		super();
	}
	@Override
	public String toString() {
		return "UserBean [user_id=" + user_id + ", name=" + name + ", address="
				+ address + ", play_amount=" + play_amount + "]";
	}
	
	
}
