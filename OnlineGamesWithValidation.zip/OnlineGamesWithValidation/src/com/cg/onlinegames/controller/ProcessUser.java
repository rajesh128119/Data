package com.cg.onlinegames.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.validator.internal.util.privilegedactions.GetMethod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.onlinegames.bean.GameBean;
import com.cg.onlinegames.bean.UserBean;
import com.cg.onlinegames.exception.OnlineGamesException;
import com.cg.onlinegames.service.ProcessService;
import com.cg.onlinegames.service.ProcessServiceImpl;

@Controller
public class ProcessUser {
	int bal = 0;
     
	@Autowired
	ProcessService service;
	
	@Autowired
	UserBean userBean;
	
	@RequestMapping(value="/showHomePage")
	public String showHomePage(Model model)
	{
		System.out.println("hiiiii");
		  model.addAttribute("userBean",userBean);
		  System.out.println("controller output in userbean"+userBean);
		  return "gamecity";//Logical view name
	}

	@RequestMapping(value="/insertUser.obj")
	public String inertUser(@ModelAttribute("userBean")@Valid UserBean bean,BindingResult result,Model model)
	{
		if(result.hasErrors())
		{
			System.out.println("error");
			//model.addAttribute("userBean",userBean);
			 return "gamecity";
		}
		else
		{
		ArrayList<GameBean> gameList = new ArrayList<GameBean>();
			
		try {
			System.out.println(bean);
			userBean=service.insertUser(bean);	//insert data into table
			int serviceCharge = 100;
			int userAmt = userBean.getPlay_amount()-serviceCharge; //service charge Rs 100 deducted from the users amount
			
			gameList = service.getGameList();
			System.out.println(userAmt);
			for(GameBean b:gameList)
			{	
				System.out.println(b);
			}
			
			model.addAttribute("userAmt",userAmt);
			model.addAttribute("gameList",gameList);
			
		
			
		} catch (OnlineGamesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "play";
		}
		
	}
	
	@RequestMapping(value="/playGame")
	public String playGame(@RequestParam("gameName") String gameName,@RequestParam("gameAmount") int gameAmount,@RequestParam("userAmount") int userAmount,Model model)
	{
		System.out.println("selected game "+gameName+"Game Amt"+gameAmount);
		System.out.println("user userAmount: "+userAmount);
		
		userAmount = userAmount -  bal;
		System.out.println(bal);
		  if(gameAmount>userAmount)
		  {
			 model.addAttribute("gameName", gameName);
			  return "Topup";
		  }
		  else
		  {
			  bal = bal + gameAmount;
			  model.addAttribute("gameName", gameName);
			  model.addAttribute("userAmount", userAmount-gameAmount);
			  return "Success";
		  }
	}
}
