package com.cg.game.gamecontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.game.entities.GameCity;
import com.cg.game.service.GameService;



@Controller
public class GameController {
	@Autowired
	GameService service;
	
	@RequestMapping(value = "/login")
	public String passParam(Model model)
	{
		model.addAttribute(new GameCity());
		return "GameCity";
	}
	
	
	@RequestMapping(value="/add")
	public String showForm(GameCity gameCity,Model model) {

		// LoginBean - loginBean
		// model.addAttribute("login", new Login());
		//model.addAttribute(new GameCity());// login
		// model.addAttribute("sonar",login);
		GameCity game=service.saveUser(gameCity);
		//System.out.println(game.getName());
		model.addAttribute("name",game.getName());
		
		return "Success";// Logical view names
	}
}
