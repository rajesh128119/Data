package com.cg.game.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.game.entities.GameCity;


@Repository
public class GameDaoImpl implements GameDao {

	@PersistenceContext
	private EntityManager entityManager;

	
	@Override
	public GameCity saveUser(GameCity gameCity) {
		// TODO Auto-generated method stub
		System.out.println(entityManager);
		entityManager.persist(gameCity);
		entityManager.flush();
		return gameCity;
	}

}
