package com.cg.game.dao;

import com.cg.game.entities.GameCity;



public interface GameDao {
	public GameCity saveUser(GameCity gameCity);
}
