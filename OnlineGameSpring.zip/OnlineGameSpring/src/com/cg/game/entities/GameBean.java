package com.cg.game.entities;

import javax.persistence.Id;

import org.springframework.stereotype.Component;
@Component
public class GameBean {
	@Id
	String name;
	int amount;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	

}
