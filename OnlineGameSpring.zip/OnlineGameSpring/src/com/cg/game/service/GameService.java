package com.cg.game.service;

import com.cg.game.entities.GameCity;



public interface GameService {
	public GameCity saveUser(GameCity gameCity);

}
