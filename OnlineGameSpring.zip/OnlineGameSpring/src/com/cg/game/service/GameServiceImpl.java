package com.cg.game.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.game.dao.GameDao;
import com.cg.game.entities.GameCity;

@Service
@Transactional
public class GameServiceImpl implements GameService {
	@Autowired
	GameDao dao;

	@Override
	public GameCity saveUser(GameCity gameCity) {
		// TODO Auto-generated method stub
		return dao.saveUser(gameCity);
	}

	

	
}
